package bankConsoleApplication;

public class ManageUser {
    public void login(User user){

    }
    public void register(){}
}
