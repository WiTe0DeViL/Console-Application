package busReservationSystem;

public class BusReservation {
    public static void main(String[] args) {
        new BookingProcess().Options();
    }
}
